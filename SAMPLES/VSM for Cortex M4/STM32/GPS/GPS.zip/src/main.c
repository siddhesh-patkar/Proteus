/**
 * Keil project example for GPS
 *
 * Before you start, select your target, on the right of the "Load" button
 *
 * @author    Tilen Majerle
 * @email     tilen@majerle.eu
 * @website   http://stm32f4-discovery.net
 * @ide       Keil uVision 5
 * @conf      PLL parameters are set in "Options for Target" -> "C/C++" -> "Defines"
 * @packs     STM32F4xx/STM32F7xx Keil packs are requred with HAL driver support
 * @stdperiph STM32F4xx/STM32F7xx HAL drivers required
 */
/* Include core modules */
#include "stm32fxxx_hal.h"
/* Include my libraries here */
#include "defines.h"
#include "tm_stm32_delay.h"
#include "tm_stm32_gps.h"

/* GPS based variables */
TM_GPS_t GPS_Data;
TM_GPS_Result_t result, current;
TM_GPS_Float_t GPS_Float;
TM_GPS_Distance_t GPS_Distance;

int main(void) {
	/* Variables used */
	char buffer[40];
	uint8_t i;
	float temp;
	
	/* Initialize system */
	SystemInit();
	SystemCoreClockUpdate();
	
	/* Delay init */
	TM_DELAY_Init();
	
	/* Initialize GPS on 9600 baudrate */
	TM_GPS_Init(&GPS_Data, 9600);
	
	// USART1: wait for idleframe before data reception
	USART1->CR1 &= ~USART_CR1_RXNEIE;
	volatile uint32_t tmp = USART1->DR;
	while((USART1->SR & (1<<4))==0);
	tmp = USART1->SR;
	tmp = USART1->DR;
	USART1->CR1 |= USART_CR1_RXNEIE;
	
	//while(1){}
	
	/* Initialize USART2 for debug */
	TM_USART_Init(USART2, TM_USART_PinsPack_1, 115200);
	
	/* Version 1.1 added */
	/* Set two test coordinates */
	GPS_Distance.Latitude1 = 48.300215;
	GPS_Distance.Longitude1 = -122.285903;
	GPS_Distance.Latitude2 = 45.907813;
	GPS_Distance.Longitude2 = 56.659407;
	
	/* Calculate distance and bearing between 2 pointes */
	TM_GPS_DistanceBetween(&GPS_Distance);
	/* Convert float number */
	TM_GPS_ConvertFloat(GPS_Distance.Distance, &GPS_Float, 6);
	sprintf(buffer, "Distance is: %d.%06d meters\r\n", GPS_Float.Integer, GPS_Float.Decimal);
	TM_USART_Puts(USART2, buffer);
	TM_GPS_ConvertFloat(GPS_Distance.Bearing, &GPS_Float, 6);
	sprintf(buffer, "Bearing is: %d.%06d degrees\r\n\r\n", GPS_Float.Integer, GPS_Float.Decimal);
	TM_USART_Puts(USART2, buffer);
	
	/* Reset counter */
	TM_DELAY_SetTime(0);
	while (1) {
		/* Update GPS data */
		/* Call this as faster as possible */
		result = TM_GPS_Update(&GPS_Data);
		
		/* If we didn't receive any useful data in the start */
		if (result == TM_GPS_Result_FirstDataWaiting && TM_DELAY_Time() > 3000) {
			/* If we didn't receive nothing within 3 seconds */
			TM_DELAY_SetTime(0);
			/* Display data on USART */
			TM_USART_Puts(USART2, "\r\nNothing received after 3 seconds. Is your GPS connected and baudrate set correct?\r\n");
			TM_USART_Puts(USART2, "Most GPS receivers has by default 9600 baudrate and 1Hz refresh rate. Check your settings!\r\n\r\n");
		}
		/* If we have any unread data */
		if (result == TM_GPS_Result_NewData) {
			/* We received new packet of useful data from GPS */
			current = TM_GPS_Result_NewData;
			
			/* Is GPS signal valid? */
			if (GPS_Data.Validity) {
				/* If you want to make a GPS tracker, now is the time to save your data on SD card */
				
				/* We have valid GPS signal */
				TM_USART_Puts(USART2, "New received data have valid GPS signal\r\n");
				TM_USART_Puts(USART2, "---------------------------------------\r\n");
#ifndef GPS_DISABLE_GPGGA
				/* GPGGA data */
				TM_USART_Puts(USART2, "GPGGA statement:\r\n");
				
				/* Latitude */
				/* Convert float to integer and decimal part, with 6 decimal places */
				TM_GPS_ConvertFloat(GPS_Data.Latitude, &GPS_Float, 6);
				sprintf(buffer, " - Latitude: %d.%d\r\n", GPS_Float.Integer, GPS_Float.Decimal);
				TM_USART_Puts(USART2, buffer);
				
				/* Longitude */
				/* Convert float to integer and decimal part, with 6 decimal places */
				TM_GPS_ConvertFloat(GPS_Data.Longitude, &GPS_Float, 6);
				sprintf(buffer, " - Longitude: %d.%d\r\n", GPS_Float.Integer, GPS_Float.Decimal);
				TM_USART_Puts(USART2, buffer);
				
				/* Satellites in use */
				sprintf(buffer, " - Sats in use: %02d\r\n", GPS_Data.Satellites);
				TM_USART_Puts(USART2, buffer);	
				
				/* Current time */
				sprintf(buffer, " - UTC Time: %02d.%02d.%02d:%02d\r\n", GPS_Data.Time.Hours, GPS_Data.Time.Minutes, GPS_Data.Time.Seconds, GPS_Data.Time.Hundredths);
				TM_USART_Puts(USART2, buffer);
				
				/* Fix: 0 = invalid, 1 = GPS, 2 = DGPS */
				sprintf(buffer, " - Fix: %d\r\n", GPS_Data.Fix);
				TM_USART_Puts(USART2, buffer);				
				
				/* Altitude */
				/* Convert float to integer and decimal part, with 6 decimal places */
				TM_GPS_ConvertFloat(GPS_Data.Altitude, &GPS_Float, 6);
				sprintf(buffer, " - Altitude: %3d.%06d\r\n", GPS_Float.Integer, GPS_Float.Decimal);
				TM_USART_Puts(USART2, buffer);				
#endif
#ifndef GPS_DISABLE_GPRMC
				/* GPRMC data */
				TM_USART_Puts(USART2, "GPRMC statement:\r\n");
				
				/* Current date */
				sprintf(buffer, " - Date: %02d.%02d.%04d\r\n", GPS_Data.Date.Date, GPS_Data.Date.Month, GPS_Data.Date.Year + 2000);
				TM_USART_Puts(USART2, buffer);
				
				/* Current speed in knots */
				TM_GPS_ConvertFloat(GPS_Data.Speed, &GPS_Float, 6);
				sprintf(buffer, " - Speed in knots: %d.%06d\r\n", GPS_Float.Integer, GPS_Float.Decimal);
				TM_USART_Puts(USART2, buffer);
				
				/* Current speed in km/h */
				temp = TM_GPS_ConvertSpeed(GPS_Data.Speed, TM_GPS_Speed_KilometerPerHour);
				TM_GPS_ConvertFloat(temp, &GPS_Float, 6);
				sprintf(buffer, " - Speed in km/h: %d.%06d\r\n", GPS_Float.Integer, GPS_Float.Decimal);
				TM_USART_Puts(USART2, buffer);
				
				TM_GPS_ConvertFloat(GPS_Data.Direction, &GPS_Float, 3);
				sprintf(buffer, " - Direction: %3d.%03d\r\n", GPS_Float.Integer, GPS_Float.Decimal);
				TM_USART_Puts(USART2, buffer);
#endif
#ifndef GPS_DISABLE_GPGSA
				/* GPGSA data */
				TM_USART_Puts(USART2, "GPGSA statement:\r\n");
				
				/* Horizontal dilution of precision */ 
				TM_GPS_ConvertFloat(GPS_Data.HDOP, &GPS_Float, 2);
				sprintf(buffer, " - HDOP: %2d.%02d\r\n", GPS_Float.Integer, GPS_Float.Decimal);
				TM_USART_Puts(USART2, buffer);
				
				/* Vertical dilution of precision */ 
				TM_GPS_ConvertFloat(GPS_Data.VDOP, &GPS_Float, 2);
				sprintf(buffer, " - VDOP: %2d.%02d\r\n", GPS_Float.Integer, GPS_Float.Decimal);
				TM_USART_Puts(USART2, buffer);
				
				/* Position dilution of precision */ 
				TM_GPS_ConvertFloat(GPS_Data.PDOP, &GPS_Float, 2);
				sprintf(buffer, " - PDOP: %2d.%02d\r\n", GPS_Float.Integer, GPS_Float.Decimal);
				TM_USART_Puts(USART2, buffer);	
				
				/* Current fix mode in use */ 
				sprintf(buffer, " - Fix mode: %d\r\n", GPS_Data.FixMode);
				TM_USART_Puts(USART2, buffer);
				
				/* Display IDs of satellites in use */
				TM_USART_Puts(USART2, "- ID's of used satellites: ");
				for (i = 0; i < GPS_Data.Satellites; i++) {
					if (i < (GPS_Data.Satellites - 1)) {
						sprintf(buffer, "%d,", GPS_Data.SatelliteIDs[i]);
					} else {
						sprintf(buffer, "%d\r\n", GPS_Data.SatelliteIDs[i]);
					}
					TM_USART_Puts(USART2, buffer);
				}
				
#endif
#ifndef GPS_DISABLE_GPGSV
				/* GPGSV data */
				TM_USART_Puts(USART2, "GPGSV statement:\r\n");
				
				/* Satellites in view */
				sprintf(buffer, " - Satellites in view: %d\r\n", GPS_Data.SatellitesInView);
				TM_USART_Puts(USART2, buffer);	
#endif
				TM_USART_Puts(USART2, "---------------------------------------\r\n");
			} else {
				/* GPS signal is not valid */
				TM_USART_Puts(USART2, "New received data haven't valid GPS signal!\r\n");
			}
		} else if (result == TM_GPS_Result_FirstDataWaiting && current != TM_GPS_Result_FirstDataWaiting) {
			current = TM_GPS_Result_FirstDataWaiting;
			TM_USART_Puts(USART2, "Waiting first data from GPS!\r\n");
		} else if (result == TM_GPS_Result_OldData && current != TM_GPS_Result_OldData) {
			current = TM_GPS_Result_OldData;
			/* We already read data, nothing new was received from GPS */
		}
	}
}
